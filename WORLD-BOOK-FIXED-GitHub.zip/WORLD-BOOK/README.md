# WORLD BOOK — fixed build
Created by Nirmit Arun Pohane.

## Publish
Upload `index.html` to the root of your GitHub repository, then enable GitHub Pages:
Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.

## What's fixed
- Google Books is attempted first.
- If Google Books errors or returns no results, Open Library is tried as a backup.
- Status messages distinguish no results from connection failures.

## Notes
This is a static GitHub Pages web app, not an Android APK.
Saved items use browser local storage and do not sync across devices.
Catalogue records do not guarantee full-text access. Full downloads are available only where the provider permits them.
The language filter applies to Google Books results; Open Library fallback search does not promise a matching language.
